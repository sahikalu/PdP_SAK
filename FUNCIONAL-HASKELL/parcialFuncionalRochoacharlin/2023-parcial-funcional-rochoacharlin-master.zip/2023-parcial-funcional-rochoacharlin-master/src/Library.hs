module Library where
import PdePreludat

doble :: Number -> Number
doble numero = numero + numero

-- 1
data Auto = Auto{
    marca :: String,
    modelo :: String,
    desgasteDeChasis :: Number,
    desgasteDeRuedas :: Number,
    velocidadMax :: Number,
    tiempoDeCarrera :: Number
} deriving Show

-- 1a
ferrari = Auto "Ferrari" "F50" 0 0 65 0
lamborghini = Auto "Lamborghini" "Diablo" 7 4 73 0
fiat = Auto "Fiat" "600" 33 27 44 0

-- 2a
estaEnBuenEstado auto = ((< 40) . desgasteDeChasis) auto && ((< 60) . desgasteDeRuedas) auto

-- 2b
noDaMas auto = ((> 80) . desgasteDeChasis) auto || ((> 80) . desgasteDeRuedas) auto

-- 3
desgastarChasis desgaste auto = auto{desgasteDeChasis = (+desgaste).desgasteDeChasis $ auto}
desgastarRuedas desgaste auto = auto{desgasteDeRuedas = (+desgaste).desgasteDeRuedas $ auto}

reparar auto = desgastarRuedas (negate.desgasteDeRuedas $ auto).desgastarChasis (negate (85*desgasteDeChasis auto/100)) $ auto

-- 4
type Parte = Auto -> Auto
type Pista = [Parte]

sumarTiempo tiempo auto = auto{tiempoDeCarrera = (+tiempo).tiempoDeCarrera $ auto}

parte :: (Auto->Auto) -> Number -> Auto -> Auto
parte desgasteQueProduce tiempoQueToma auto = sumarTiempo tiempoQueToma.desgasteQueProduce $ auto

-- 4a
curva angulo longitud auto = parte desgaste tiempo auto
    where 
        desgaste = desgastarRuedas (1 / (angulo * 7 * longitud))
        tiempo = (longitud /).(/ 2).velocidadMax $ auto

curvaPeligrosa = curva 60 300
curvaTranca = curva 110 550

-- 4b
tramoRecto longitud auto = parte desgaste tiempo auto
    where
        desgaste = desgastarChasis.(/100).desgasteDeChasis $ auto
        tiempo = (longitud /). velocidadMax $ auto

tramoRectoClassic = tramoRecto 750
tramito = tramoRecto 280

-- 4c
boxes tramo auto
    | estaEnBuenEstado auto = tramo auto
    | otherwise             = sumarTiempo 10.reparar.tramo $ auto

-- 4d
tramoMojado tramo auto = sumarTiempo (tiempoAgregadoPorTramo/2).tramo $ auto
    where tiempoAgregadoPorTramo = (tiempoDeCarrera.tramo) auto - tiempoDeCarrera auto 

-- 4e
tramoConRipio tramo = tramo.tramo

-- 4f
tramoConObstruccion largoDeObstruccion tramo auto = desgasteProducido.tramo $ auto
    where desgasteProducido = desgastarChasis (2*largoDeObstruccion)

-- 5
pasarPorTramo tramo auto
    | not.noDaMas $ auto = tramo auto
    | otherwise = auto

-- 6a
superPista = [tramoRectoClassic, curvaTranca, tramito.tramoMojado tramito, tramoConObstruccion 2 (curva 80 400),
    curva 115 650, tramoRecto 970, curvaPeligrosa, tramoConRipio tramito, boxes (tramoRecto 800)]

-- 6b
peganLaVuelta :: Pista -> [Auto] -> [Auto]
peganLaVuelta pista autos = map pegaLaVuelta autos
    where pegaLaVuelta auto = foldr pasarPorTramo auto . reverse $ pista

-- 7a
data Carrera = Carrera{
    pista :: Pista,
    nroDeVueltas :: Number
}

-- 7b
tourBuenosAires = Carrera superPista 20

-- 7c
hacerCarrera carrera autos = map (quitarALosQueNoDanMas.resultadosDeLaVuelta) [1..nroDeVueltas carrera]
    where 
        resultadosDeLaVuelta nroDeVuelta = flip peganLaVuelta autos. flip take (pista carrera) $ nroDeVuelta
        quitarALosQueNoDanMas autosQueCorrieron = filter (not.noDaMas) autosQueCorrieron

{-- 8

myPrecious ts x = 
	sum . map (($ snd x) . snd) . filter ((>5) . length . fst x) $ ts

myPrecious :: [(a, c -> Number)] -> ( (a, c -> Number) -> [b] , c ) -> Number

1) Salida
    myPrecious es una composición cuya última función es sum. Por lo tanto, myPrecious devuelve un número.

2) 2do parámetro: x
    A x se le aplica fst en una ocasión y snd en otra. x es una tupla.
    El 1er elemento de la tupla ha de ser una función, pues forma parte de una composición. Esta función
    debe esperar un elemento de ts y transformarlo en una lista, por el length que se aplica luego.
    El 2do elemento de la tupla es argumento del 2do elemento de los elementos de ts.

3) 1er parámetro: ts
    filter está aplicada parcialmente y es la primera en la composición. Como se le pasa ts, ts debe ser una lista.
    A cada elemento de ts se le puede aplicar snd, visto en la función de map. Cada elemento es una tupla.
    El 2do elemento de la tupla es una función que recibe el 2do elemento de x y lo transforma en un número,
    pues map debe darle una lista de números a sum.
--}
