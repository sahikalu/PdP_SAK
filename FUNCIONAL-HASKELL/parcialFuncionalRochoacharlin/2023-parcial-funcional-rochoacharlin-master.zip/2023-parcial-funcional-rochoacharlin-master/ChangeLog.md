# Changelog for 2023ParcialFuncional

## Unreleased changes
